import React from "react";

const SlideTypeC = () => {
  return <div>SlideTypeC</div>;
};

export default SlideTypeC;
