// types/prize.types.ts o types/views.ts
export type IView = "DM" | "SM" | "PM"; // Lo que tengas definido

// Agrega en el tipo del store:
view: IView;
setView: (view: IView) => void;
