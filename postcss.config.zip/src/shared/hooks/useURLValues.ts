// shared/hooks/useURLValues.ts
import { useEffect } from "react";
import { usePrizesStore } from "../store/prizesStore";
import { Default } from "../lib/constants";
import { IView } from "../types/views"; // Define este enum si no lo tienes

export const useURLValues = () => {
  const { setTarjetaId, setNroAsset, setView } = usePrizesStore();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const card = params.get("id") ?? Default.card;
    const machine = params.get("asset") ?? Default.machine;
    const view = (params.get("iview") ?? Default.view).toUpperCase() as IView;

    setTarjetaId(card);
    setNroAsset(Number(machine));
    setView(view);
  }, []);
};
